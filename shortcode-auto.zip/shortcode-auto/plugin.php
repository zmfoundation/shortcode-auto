<?php 
/**
 * Plugin name: Shortcode Auto 
 * Description: Automatic shortcode testing 
 * Author: Zakaria 
 * Text Domain: shortcode-auto
 */

if (! defined('ABSPATH') ) {
	exit();
}

/**
 * CPT Create 
 */

// Register Custom Post Type Book
function sha_cpt_create() {

	$labels = array(
		'name' => _x( 'Books', 'Post Type General Name', 'shortcode-auto' ),
		'singular_name' => _x( 'Book', 'Post Type Singular Name', 'shortcode-auto' ),
		'menu_name' => _x( 'Books', 'Admin Menu text', 'shortcode-auto' ),
		'name_admin_bar' => _x( 'Book', 'Add New on Toolbar', 'shortcode-auto' ),
		'archives' => __( 'Book Archives', 'shortcode-auto' ),
		'attributes' => __( 'Book Attributes', 'shortcode-auto' ),
		'parent_item_colon' => __( 'Parent Book:', 'shortcode-auto' ),
		'all_items' => __( 'All Books', 'shortcode-auto' ),
		'add_new_item' => __( 'Add New Book', 'shortcode-auto' ),
		'add_new' => __( 'Add New', 'shortcode-auto' ),
		'new_item' => __( 'New Book', 'shortcode-auto' ),
		'edit_item' => __( 'Edit Book', 'shortcode-auto' ),
		'update_item' => __( 'Update Book', 'shortcode-auto' ),
		'view_item' => __( 'View Book', 'shortcode-auto' ),
		'view_items' => __( 'View Books', 'shortcode-auto' ),
		'search_items' => __( 'Search Book', 'shortcode-auto' ),
		'not_found' => __( 'Not found', 'shortcode-auto' ),
		'not_found_in_trash' => __( 'Not found in Trash', 'shortcode-auto' ),
		'featured_image' => __( 'Featured Image', 'shortcode-auto' ),
		'set_featured_image' => __( 'Set featured image', 'shortcode-auto' ),
		'remove_featured_image' => __( 'Remove featured image', 'shortcode-auto' ),
		'use_featured_image' => __( 'Use as featured image', 'shortcode-auto' ),
		'insert_into_item' => __( 'Insert into Book', 'shortcode-auto' ),
		'uploaded_to_this_item' => __( 'Uploaded to this Book', 'shortcode-auto' ),
		'items_list' => __( 'Books list', 'shortcode-auto' ),
		'items_list_navigation' => __( 'Books list navigation', 'shortcode-auto' ),
		'filter_items_list' => __( 'Filter Books list', 'shortcode-auto' ),
	);
	$args = array(
		'label' => __( 'Book', 'shortcode-auto' ),
		'description' => __( 'Simple book type', 'shortcode-auto' ),
		'labels' => $labels,
		'menu_icon' => 'dashicons-book-alt',
		'supports' => array('title', 'excerpt', 'thumbnail'),
		'taxonomies' => array(),
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_position' => 5,
		'show_in_admin_bar' => true,
		'show_in_nav_menus' => true,
		'can_export' => true,
		'has_archive' => true,
		'hierarchical' => false,
		'exclude_from_search' => false,
		'show_in_rest' => true,
		'publicly_queryable' => true,
		'capability_type' => 'post',
	);
	register_post_type( 'book', $args );

}
add_action( 'init', 'sha_cpt_create', 0 );


/**
 * Column management 
 */

function sha_column_manage( $columns ){ 
	unset($columns['date']);
	$columns['shotcode'] = __( 'Shortcode', 'shortcode-auto' );
	$columns['date'] = __( 'Date', 'shortcode-auto' );
	return $columns;
}
add_filter( 'manage_book_posts_columns', 'sha_column_manage' );


/**
 * Shortcode value 
 */
function sha_manage_shortcode_cols( $columns, $post_id ){ 

	echo "<input type='text' value='[sha_shortcode_id={$post_id}]' readonly />";

}
add_action( 'manage_book_posts_custom_column', 'sha_manage_shortcode_cols', 10,2 );


/**
 * Shortcode Generate 
 */

 function sha_book($atts) {

    $a = shortcode_atts( array(
        'posts_per_page' => '',
    ), $atts );

    $book = '';
    $posts_per_page = esc_attr($a['posts_per_page']);

    $args = array(
        'post__in' => get_the_ID(),
        'posts_per_page' => $posts_per_page,
        'post_type'        => 'book',
    );

    // the query
    $the_query = new WP_Query( $args );

    if ( $the_query->have_posts() ) :
	    while ( $the_query->have_posts() ) : $the_query->the_post();
	        $book.= '<div class="title">'.get_the_title().'</div>';
	        $book.= '<div class="content">'.get_the_excerpt().'</div>';
	    endwhile;
    endif;
    return $book;
}
add_shortcode('sha_shortcode_id='.get_the_ID(), 'sha_book' );






